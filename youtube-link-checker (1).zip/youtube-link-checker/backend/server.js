import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/check', async (req, res) => {
  const urls = req.body.urls || [];
  const results = await Promise.all(urls.map(async url => {
    try {
      const r = await fetch(url);
      const t = await r.text();
      const status = t.includes("This video is private") ? 'private' :
                     t.includes("Sign in to confirm your age") ? 'age-restricted' :
                     t.includes("Video unavailable") ? 'deleted' :
                     (r.status === 200 ? 'available' : 'error');
      return { url, status };
    } catch {
      return { url, status: 'error' };
    }
  }));
  res.json(results);
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}`));
